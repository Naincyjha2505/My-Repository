My java program contained in main.java file reads the data from "input.txt" file using fileinputstream from the given location in program 
where the file is located.

The program then creates and writes the output in the "output.txt" using fileoutputstream at the given location in the program. 
The output is in the same format as given in the problem instructions. 

I have ran the three test cases and have recorded it in the video. 
TC 1 - 4 employees.
TC 2- 6 employees.
TC 3 - 2 employees.
